function convertNumber(conversionType) {
    var decimalValue = document.getElementById("decimal").value;

    // Make an AJAX request to the servlet
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Update the result in the same page
            document.getElementById("result").innerHTML = xhr.responseText;
        }
    };

    // Construct the URL with the decimal value and conversion type
    var url = "NumberConvertor?decimal=" + encodeURIComponent(decimalValue)
            + "&conversionType=" + encodeURIComponent(conversionType);

    // Open the connection and send the request
    xhr.open("GET", url, true);
    xhr.send();
}
